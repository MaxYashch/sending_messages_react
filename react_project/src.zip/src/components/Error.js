function Error() {
    return (
        <>
            <div class="p-3 mb-2 bg-primary text-white mt-3 text-center">
                404 The page doesn't exist
            </div>
        </>
    );
}

export default Error;
